package alex;

public class ClaseLexica {
  public static final int EOF = 0;
  public static final int DONDE = 2;
  public static final int EVALUA = 3;
  public static final int IDEN = 4;
  public static final int ENT = 5;
  public static final int REAL = 6;
  public static final int MAS = 7;
  public static final int MENOS = 8;
  public static final int POR = 9;
  public static final int DIV = 10;
  public static final int IGUAL = 11;
  public static final int COMA = 12;
  public static final int PAP = 13;
  public static final int PCIERRE = 14;
}
